import { Empresa } from '../entities/empresa.entity';
import { Repository } from 'typeorm';
import { CreateEmpresaDto } from '../dtos/empresa.dto';
import { Usuario } from 'src/usuarios/entities/usuario.entity';
export declare class EmpresasService {
    private readonly empresaRepository;
    private readonly usuarioRepo;
    constructor(empresaRepository: Repository<Empresa>, usuarioRepo: Repository<Usuario>);
    findAll(): Promise<Empresa[]>;
    findOne(id: number): Promise<Empresa | null>;
    findByPropietario(propietarioId: number): Promise<Empresa[]>;
    create(createEmpresaDto: CreateEmpresaDto, propietarioId: number): Promise<Empresa>;
    update(id: number, empresa: Partial<Empresa>): Promise<Empresa | null>;
    remove(id: number): Promise<void>;
}
