"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Empresa = void 0;
const typeorm_1 = require("typeorm");
const usuario_entity_1 = require("../../usuarios/entities/usuario.entity");
const servicio_entity_1 = require("../../servicios/entities/servicio.entity");
const resena_entity_1 = require("../../resenas/entities/resena.entity");
const post_entity_1 = require("../../posts/entities/post.entity");
const class_validator_1 = require("class-validator");
let Empresa = class Empresa {
    id;
    nombre;
    descripcion;
    direccion;
    telefono;
    latitud;
    longitud;
    horario;
    urlAvatar;
    urlPortada;
    webSite;
    fechaRegistro;
    propietario;
    resenas;
    email;
    posts;
    servicios;
};
exports.Empresa = Empresa;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)({ name: 'id_empresa' }),
    __metadata("design:type", Number)
], Empresa.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'nombre_empresa', type: 'varchar', length: 150 }),
    __metadata("design:type", String)
], Empresa.prototype, "nombre", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], Empresa.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], Empresa.prototype, "direccion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20, nullable: true }),
    __metadata("design:type", String)
], Empresa.prototype, "telefono", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 8 }),
    __metadata("design:type", Number)
], Empresa.prototype, "latitud", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 11, scale: 8 }),
    __metadata("design:type", Number)
], Empresa.prototype, "longitud", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], Empresa.prototype, "horario", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'url_avatar', type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], Empresa.prototype, "urlAvatar", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'url_portada', type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], Empresa.prototype, "urlPortada", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'web_site', type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], Empresa.prototype, "webSite", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'fecha_registro', type: 'timestamp' }),
    __metadata("design:type", Date)
], Empresa.prototype, "fechaRegistro", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => usuario_entity_1.Usuario, (usuario) => usuario.empresas, {
        nullable: false,
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'id_propietario' }),
    __metadata("design:type", usuario_entity_1.Usuario)
], Empresa.prototype, "propietario", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => resena_entity_1.Resena, (resena) => resena.empresa),
    __metadata("design:type", Array)
], Empresa.prototype, "resenas", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, unique: true, nullable: true }),
    (0, class_validator_1.IsEmail)(),
    __metadata("design:type", String)
], Empresa.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => post_entity_1.Post, (post) => post.empresa),
    __metadata("design:type", Array)
], Empresa.prototype, "posts", void 0);
__decorate([
    (0, typeorm_1.ManyToMany)(() => servicio_entity_1.Servicio, (servicio) => servicio.empresas),
    (0, typeorm_1.JoinTable)({
        name: 'empresa_servicios',
        joinColumn: { name: 'id_empresa' },
        inverseJoinColumn: { name: 'id_servicio' },
    }),
    __metadata("design:type", Array)
], Empresa.prototype, "servicios", void 0);
exports.Empresa = Empresa = __decorate([
    (0, typeorm_1.Entity)('empresas')
], Empresa);
//# sourceMappingURL=empresa.entity.js.map