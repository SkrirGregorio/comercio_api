"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteImageDto = exports.UploadImageDto = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const upload_interface_1 = require("../interfaces/upload.interface");
class UploadImageDto {
    type;
    maxSize;
}
exports.UploadImageDto = UploadImageDto;
__decorate([
    (0, class_validator_1.IsEnum)(upload_interface_1.ImageType),
    __metadata("design:type", String)
], UploadImageDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => parseInt(value, 10)),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(100),
    (0, class_validator_1.Max)(10 * 1024 * 1024),
    __metadata("design:type", Number)
], UploadImageDto.prototype, "maxSize", void 0);
class DeleteImageDto {
    type;
}
exports.DeleteImageDto = DeleteImageDto;
__decorate([
    (0, class_validator_1.IsEnum)(upload_interface_1.ImageType),
    __metadata("design:type", String)
], DeleteImageDto.prototype, "type", void 0);
//# sourceMappingURL=upload.dto.js.map