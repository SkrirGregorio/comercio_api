"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResenasService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const resena_entity_1 = require("../entities/resena.entity");
const empresa_entity_1 = require("../../empresas/entities/empresa.entity");
const usuario_entity_1 = require("../../usuarios/entities/usuario.entity");
let ResenasService = class ResenasService {
    resenaRepo;
    empresaRepo;
    usuarioRepo;
    constructor(resenaRepo, empresaRepo, usuarioRepo) {
        this.resenaRepo = resenaRepo;
        this.empresaRepo = empresaRepo;
        this.usuarioRepo = usuarioRepo;
    }
    async create(createResenaDto, userId) {
        const { idEmpresa, ...resenaData } = createResenaDto;
        const empresa = await this.empresaRepo.findOne({
            where: { id: idEmpresa },
        });
        if (!empresa) {
            throw new common_1.NotFoundException(`Empresa con ID #${idEmpresa} no encontrada.`);
        }
        const usuario = await this.usuarioRepo.findOne({
            where: { id: userId },
        });
        if (!usuario) {
            throw new common_1.NotFoundException(`Usuario con ID #${userId} no encontrado.`);
        }
        const empresaConPropietario = await this.empresaRepo.findOne({
            where: { id: idEmpresa },
            relations: ['propietario'],
        });
        if (empresaConPropietario?.propietario?.id === userId) {
            throw new common_1.BadRequestException('No puedes reseñar tu propia empresa.');
        }
        const resenaExistente = await this.resenaRepo.findOne({
            where: {
                empresa: { id: idEmpresa },
                usuario: { id: userId },
            },
        });
        if (resenaExistente) {
            throw new common_1.BadRequestException('Ya has reseñado esta empresa.');
        }
        const nuevaResena = this.resenaRepo.create({
            ...resenaData,
            empresa,
            usuario,
        });
        return this.resenaRepo.save(nuevaResena);
    }
    findAll() {
        return this.resenaRepo.find({
            relations: ['empresa', 'usuario'],
        });
    }
    async findByEmpresa(empresaId) {
        const empresa = await this.empresaRepo.findOne({
            where: { id: empresaId },
        });
        if (!empresa) {
            throw new common_1.NotFoundException(`Empresa con ID #${empresaId} no encontrada.`);
        }
        return this.resenaRepo.find({
            where: { empresa: { id: empresaId } },
            relations: ['usuario'],
            order: { createdAt: 'DESC' },
        });
    }
    async findOne(id) {
        const resena = await this.resenaRepo.findOne({
            where: { id },
            relations: ['empresa', 'usuario'],
        });
        if (!resena) {
            throw new common_1.NotFoundException(`Reseña con ID #${id} no encontrada.`);
        }
        return resena;
    }
    async update(id, updateResenaDto, userId) {
        const resena = await this.findOne(id);
        if (!resena.usuario || resena.usuario.id !== userId) {
            throw new common_1.UnauthorizedException('Solo puedes editar tus propias reseñas.');
        }
        const { idEmpresa, ...updateData } = updateResenaDto;
        this.resenaRepo.merge(resena, updateData);
        return this.resenaRepo.save(resena);
    }
    async remove(id, userId) {
        const resena = await this.findOne(id);
        if (!resena.usuario || resena.usuario.id !== userId) {
            throw new common_1.UnauthorizedException('Solo puedes eliminar tus propias reseñas.');
        }
        const result = await this.resenaRepo.delete(id);
        if (result.affected === 0) {
            throw new common_1.NotFoundException(`Reseña con ID #${id} no encontrada.`);
        }
    }
};
exports.ResenasService = ResenasService;
exports.ResenasService = ResenasService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(resena_entity_1.Resena)),
    __param(1, (0, typeorm_1.InjectRepository)(empresa_entity_1.Empresa)),
    __param(2, (0, typeorm_1.InjectRepository)(usuario_entity_1.Usuario)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], ResenasService);
//# sourceMappingURL=resenas.service.js.map