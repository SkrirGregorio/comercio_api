export declare class UpdateUsuarioDto {
    nombre?: string;
    photoUrl?: string;
}
