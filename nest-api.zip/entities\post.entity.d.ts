import { Empresa } from '../../empresas/entities/empresa.entity';
export declare class Post {
    id: number;
    titulo: string;
    contenido: string;
    urlImagen: string;
    createdAt: Date;
    updatedAt: Date;
    empresa: Empresa;
}
