export declare class ResenasModule {
}
