import { UsuarioService } from '../services/usuario.service';
import { Role } from '../entities/usuario.entity';
import { UpdateUsuarioDto } from '../dto/create-usuario.dto';
export declare class UsuarioController {
    private readonly usuarioService;
    constructor(usuarioService: UsuarioService);
    findAll(): Promise<import("../entities/usuario.entity").Usuario[]>;
    findOne(id: number): Promise<import("../entities/usuario.entity").Usuario | null>;
    update(id: number, updateUsuarioDto: UpdateUsuarioDto): Promise<import("../entities/usuario.entity").Usuario>;
    updateRole(id: number, role: Role): Promise<import("../entities/usuario.entity").Usuario>;
}
