import { Role } from '../entities/usuario.entity';
export declare class UpdateRoleDto {
    role: Role;
}
