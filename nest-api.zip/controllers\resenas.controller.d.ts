import { ResenasService } from '../services/resenas.service';
import { CreateResenaDto, UpdateResenaDto } from '../dtos/resena.dto';
export declare class ResenasController {
    private readonly resenasService;
    constructor(resenasService: ResenasService);
    create(createResenaDto: CreateResenaDto, userId: number): Promise<import("../entities/resena.entity").Resena>;
    findAll(): Promise<import("../entities/resena.entity").Resena[]>;
    findByEmpresa(empresaId: number): Promise<import("../entities/resena.entity").Resena[]>;
    findOne(id: number): Promise<import("../entities/resena.entity").Resena>;
    update(id: number, updateResenaDto: UpdateResenaDto, userId: number): Promise<import("../entities/resena.entity").Resena>;
    remove(id: number, userId: number): Promise<void>;
}
