import { Usuario, Role } from '../entities/usuario.entity';
import { Repository } from 'typeorm';
import { CreateUsuarioDto } from '../dto/create-usuario.dto';
export declare class UsuarioService {
    private usuarioRepository;
    constructor(usuarioRepository: Repository<Usuario>);
    create(userDto: CreateUsuarioDto): Promise<Usuario>;
    findByEmail(email: string): Promise<Usuario | null>;
    findOne(id: number): Promise<Usuario | null>;
    update(id: number, updateData: Partial<Usuario>): Promise<Usuario>;
    findAll(): Promise<Usuario[]>;
    updateRole(id: number, role: Role): Promise<Usuario>;
}
