import { Usuario } from '../../usuarios/entities/usuario.entity';
import { Servicio } from '../../servicios/entities/servicio.entity';
import { Resena } from '../../resenas/entities/resena.entity';
import { Post } from '../../posts/entities/post.entity';
export declare class Empresa {
    id: number;
    nombre: string;
    descripcion: string;
    direccion: string;
    telefono: string;
    latitud: number;
    longitud: number;
    horario: string;
    urlAvatar: string;
    urlPortada: string;
    webSite: string;
    fechaRegistro: Date;
    propietario: Usuario;
    resenas: Resena[];
    email: string;
    posts: Post[];
    servicios: Servicio[];
}
