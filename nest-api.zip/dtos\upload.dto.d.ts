import { ImageType } from '../interfaces/upload.interface';
export declare class UploadImageDto {
    type: ImageType;
    maxSize?: number;
}
export declare class DeleteImageDto {
    type: ImageType;
}
