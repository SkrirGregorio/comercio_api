import { Empresa } from '../../empresas/entities/empresa.entity';
import { Usuario } from '../../usuarios/entities/usuario.entity';
export declare class Resena {
    id: number;
    calificacion: number;
    comentario: string;
    createdAt: Date;
    updatedAt: Date;
    empresa: Empresa;
    usuario: Usuario;
}
