"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResenasController = void 0;
const common_1 = require("@nestjs/common");
const resenas_service_1 = require("../services/resenas.service");
const resena_dto_1 = require("../dtos/resena.dto");
const jwt_auth_guard_1 = require("../../auth/guards/jwt-auth.guard");
const public_decorator_1 = require("../../auth/decorators/public.decorator");
const get_user_decorator_1 = require("../../auth/decorators/get-user.decorator");
let ResenasController = class ResenasController {
    resenasService;
    constructor(resenasService) {
        this.resenasService = resenasService;
    }
    create(createResenaDto, userId) {
        return this.resenasService.create(createResenaDto, userId);
    }
    findAll() {
        return this.resenasService.findAll();
    }
    findByEmpresa(empresaId) {
        return this.resenasService.findByEmpresa(empresaId);
    }
    findOne(id) {
        return this.resenasService.findOne(id);
    }
    update(id, updateResenaDto, userId) {
        return this.resenasService.update(id, updateResenaDto, userId);
    }
    remove(id, userId) {
        return this.resenasService.remove(id, userId);
    }
};
exports.ResenasController = ResenasController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, get_user_decorator_1.GetUser)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [resena_dto_1.CreateResenaDto, Number]),
    __metadata("design:returntype", void 0)
], ResenasController.prototype, "create", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ResenasController.prototype, "findAll", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('empresa/:empresaId'),
    __param(0, (0, common_1.Param)('empresaId', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], ResenasController.prototype, "findByEmpresa", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], ResenasController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, get_user_decorator_1.GetUser)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, resena_dto_1.UpdateResenaDto, Number]),
    __metadata("design:returntype", void 0)
], ResenasController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, get_user_decorator_1.GetUser)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number]),
    __metadata("design:returntype", void 0)
], ResenasController.prototype, "remove", null);
exports.ResenasController = ResenasController = __decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('resenas'),
    __metadata("design:paramtypes", [resenas_service_1.ResenasService])
], ResenasController);
//# sourceMappingURL=resenas.controller.js.map