export declare class CreatePostDto {
    titulo: string;
    contenido: string;
    slug?: string;
    tags?: string[];
    published?: boolean;
    urlImagen?: string;
    publishedAt?: string;
    empresaId: number;
}
declare const UpdatePostDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreatePostDto>>;
export declare class UpdatePostDto extends UpdatePostDto_base {
}
export {};
