import { Request as ExpressRequest } from 'express';
import { EmpresasService } from '../services/empresas.service';
import { CreateEmpresaDto, UpdateEmpresaDto } from '../dtos/empresa.dto';
export declare class EmpresasController {
    private readonly empresasService;
    constructor(empresasService: EmpresasService);
    findAll(): Promise<import("../entities/empresa.entity").Empresa[]>;
    findMyEmpresas(req: ExpressRequest & {
        user: {
            userId: number;
        };
    }): Promise<import("../entities/empresa.entity").Empresa[]>;
    findOne(id: string): Promise<import("../entities/empresa.entity").Empresa | null>;
    create(createEmpresaDto: CreateEmpresaDto, req: ExpressRequest & {
        user: {
            userId: number;
        };
    }): Promise<import("../entities/empresa.entity").Empresa>;
    update(id: string, updateEmpresaDto: UpdateEmpresaDto): Promise<import("../entities/empresa.entity").Empresa | null>;
    remove(id: string): Promise<void>;
}
