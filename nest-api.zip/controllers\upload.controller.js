"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const multer = __importStar(require("multer"));
const upload_service_1 = require("../services/upload.service");
const upload_dto_1 = require("../dtos/upload.dto");
const upload_interface_1 = require("../interfaces/upload.interface");
const jwt_auth_guard_1 = require("../../auth/guards/jwt-auth.guard");
let UploadController = class UploadController {
    uploadService;
    constructor(uploadService) {
        this.uploadService = uploadService;
    }
    uploadImage(file, uploadDto) {
        if (!file) {
            throw new common_1.BadRequestException('No se proporcionó ningún archivo');
        }
        const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!this.uploadService.validateFileType(file, allowedMimeTypes)) {
            throw new common_1.BadRequestException(`Tipo de archivo no permitido. Solo se permiten: ${allowedMimeTypes.join(', ')}`);
        }
        const maxSizes = {
            [upload_interface_1.ImageType.AVATAR]: 2 * 1024 * 1024,
            [upload_interface_1.ImageType.PORTADA]: 5 * 1024 * 1024,
            [upload_interface_1.ImageType.POST]: 3 * 1024 * 1024,
        };
        const maxSize = uploadDto.maxSize || maxSizes[uploadDto.type];
        if (file.size > maxSize) {
            throw new common_1.BadRequestException(`El archivo es demasiado grande. Tamaño máximo: ${Math.round(maxSize / 1024 / 1024)}MB`);
        }
        return this.uploadService.saveUploadedFile(file, uploadDto.type);
    }
    uploadAvatar(file) {
        if (!file) {
            throw new common_1.BadRequestException('No se proporcionó ningún archivo');
        }
        const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!this.uploadService.validateFileType(file, allowedMimeTypes)) {
            throw new common_1.BadRequestException(`Tipo de archivo no permitido. Solo se permiten: ${allowedMimeTypes.join(', ')}`);
        }
        if (file.size > 2 * 1024 * 1024) {
            throw new common_1.BadRequestException('El avatar no puede ser mayor a 2MB');
        }
        return this.uploadService.saveUploadedFile(file, upload_interface_1.ImageType.AVATAR);
    }
    uploadPortada(file) {
        if (!file) {
            throw new common_1.BadRequestException('No se proporcionó ningún archivo');
        }
        const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!this.uploadService.validateFileType(file, allowedMimeTypes)) {
            throw new common_1.BadRequestException(`Tipo de archivo no permitido. Solo se permiten: ${allowedMimeTypes.join(', ')}`);
        }
        if (file.size > 5 * 1024 * 1024) {
            throw new common_1.BadRequestException('La portada no puede ser mayor a 5MB');
        }
        return this.uploadService.saveUploadedFile(file, upload_interface_1.ImageType.PORTADA);
    }
    uploadPostImage(file) {
        if (!file) {
            throw new common_1.BadRequestException('No se proporcionó ningún archivo');
        }
        const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!this.uploadService.validateFileType(file, allowedMimeTypes)) {
            throw new common_1.BadRequestException(`Tipo de archivo no permitido. Solo se permiten: ${allowedMimeTypes.join(', ')}`);
        }
        if (file.size > 3 * 1024 * 1024) {
            throw new common_1.BadRequestException('La imagen del post no puede ser mayor a 3MB');
        }
        return this.uploadService.saveUploadedFile(file, upload_interface_1.ImageType.POST);
    }
    deleteImage(filename, deleteDto) {
        const deleted = this.uploadService.deleteFile(filename, deleteDto.type);
        if (deleted) {
            return {
                success: true,
                message: 'Archivo eliminado correctamente',
            };
        }
        else {
            return {
                success: false,
                message: 'No se pudo eliminar el archivo o no existe',
            };
        }
    }
};
exports.UploadController = UploadController;
__decorate([
    (0, common_1.Post)('image'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: multer.memoryStorage(),
        limits: { fileSize: 10 * 1024 * 1024 },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, upload_dto_1.UploadImageDto]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadImage", null);
__decorate([
    (0, common_1.Post)('avatar'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: multer.memoryStorage(),
        limits: { fileSize: 2 * 1024 * 1024 },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadAvatar", null);
__decorate([
    (0, common_1.Post)('portada'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: multer.memoryStorage(),
        limits: { fileSize: 5 * 1024 * 1024 },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadPortada", null);
__decorate([
    (0, common_1.Post)('post-image'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: multer.memoryStorage(),
        limits: { fileSize: 3 * 1024 * 1024 },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "uploadPostImage", null);
__decorate([
    (0, common_1.Delete)('image/:filename'),
    __param(0, (0, common_1.Param)('filename')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, upload_dto_1.DeleteImageDto]),
    __metadata("design:returntype", Object)
], UploadController.prototype, "deleteImage", null);
exports.UploadController = UploadController = __decorate([
    (0, common_1.Controller)('upload'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [upload_service_1.UploadService])
], UploadController);
//# sourceMappingURL=upload.controller.js.map