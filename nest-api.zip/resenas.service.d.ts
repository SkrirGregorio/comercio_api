import { Repository } from 'typeorm';
import { Resena } from '../entities/resena.entity';
import { CreateResenaDto, UpdateResenaDto } from '../dtos/resena.dto';
import { Empresa } from 'src/empresas/entities/empresa.entity';
import { Usuario } from 'src/usuarios/entities/usuario.entity';
export declare class ResenasService {
    private readonly resenaRepo;
    private readonly empresaRepo;
    private readonly usuarioRepo;
    constructor(resenaRepo: Repository<Resena>, empresaRepo: Repository<Empresa>, usuarioRepo: Repository<Usuario>);
    create(createResenaDto: CreateResenaDto, userId: number): Promise<Resena>;
    findAll(): Promise<Resena[]>;
    findByEmpresa(empresaId: number): Promise<Resena[]>;
    findOne(id: number): Promise<Resena>;
    update(id: number, updateResenaDto: UpdateResenaDto, userId: number): Promise<Resena>;
    remove(id: number, userId: number): Promise<void>;
}
