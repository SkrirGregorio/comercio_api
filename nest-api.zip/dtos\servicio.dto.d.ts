export declare class CreateServicioDto {
    nombre: string;
    descripcion?: string;
}
declare const UpdateServicioDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateServicioDto>>;
export declare class UpdateServicioDto extends UpdateServicioDto_base {
}
export {};
