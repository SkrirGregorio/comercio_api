import { ConfigService } from '@nestjs/config';
import * as multer from 'multer';
import { ImageType, UploadResult, ImageUploadOptions } from '../interfaces/upload.interface';
export declare class UploadService {
    private configService;
    private readonly uploadDir;
    private readonly baseUrl;
    constructor(configService: ConfigService);
    private ensureUploadDirectories;
    getMulterConfig(options: ImageUploadOptions): multer.Options;
    private getUploadSubdirectory;
    generateFileUrl(filename: string, type: ImageType): string;
    processUploadResult(file: Express.Multer.File, type: ImageType): UploadResult;
    deleteFile(filename: string, type: ImageType): boolean;
    validateFileType(file: Express.Multer.File, allowedTypes: string[]): boolean;
    saveUploadedFile(file: Express.Multer.File, type: ImageType): Promise<UploadResult>;
}
