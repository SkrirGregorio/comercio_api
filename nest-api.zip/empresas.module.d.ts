export declare class EmpresasModule {
}
