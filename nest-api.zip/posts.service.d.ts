import { Repository } from 'typeorm';
import { Post } from '../entities/post.entity';
import { CreatePostDto, UpdatePostDto } from '../dtos/post.dto';
import { Empresa } from 'src/empresas/entities/empresa.entity';
export declare class PostsService {
    private readonly postRepo;
    private readonly empresaRepo;
    constructor(postRepo: Repository<Post>, empresaRepo: Repository<Empresa>);
    create(createPostDto: CreatePostDto, userId: number): Promise<Post>;
    findAll(): Promise<Post[]>;
    findByEmpresa(empresaId: number): Promise<Post[]>;
    findOne(id: number): Promise<Post>;
    update(id: number, updatePostDto: UpdatePostDto, userId: number): Promise<Post>;
    remove(id: number, userId: number): Promise<void>;
}
