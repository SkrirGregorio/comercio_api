import { UploadService } from '../services/upload.service';
import { UploadImageDto, DeleteImageDto } from '../dtos/upload.dto';
import { UploadResult } from '../interfaces/upload.interface';
export declare class UploadController {
    private readonly uploadService;
    constructor(uploadService: UploadService);
    uploadImage(file: Express.Multer.File, uploadDto: UploadImageDto): Promise<UploadResult>;
    uploadAvatar(file: Express.Multer.File): Promise<UploadResult>;
    uploadPortada(file: Express.Multer.File): Promise<UploadResult>;
    uploadPostImage(file: Express.Multer.File): Promise<UploadResult>;
    deleteImage(filename: string, deleteDto: DeleteImageDto): {
        success: boolean;
        message: string;
    };
}
