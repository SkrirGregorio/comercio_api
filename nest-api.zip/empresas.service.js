"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmpresasService = void 0;
const common_1 = require("@nestjs/common");
const empresa_entity_1 = require("../entities/empresa.entity");
const typeorm_1 = require("typeorm");
const typeorm_2 = require("@nestjs/typeorm");
const usuario_entity_1 = require("../../usuarios/entities/usuario.entity");
let EmpresasService = class EmpresasService {
    empresaRepository;
    usuarioRepo;
    constructor(empresaRepository, usuarioRepo) {
        this.empresaRepository = empresaRepository;
        this.usuarioRepo = usuarioRepo;
    }
    findAll() {
        return this.empresaRepository.find({
            relations: [
                'propietario',
                'posts',
                'servicios',
                'resenas',
                'resenas.usuario',
            ],
        });
    }
    findOne(id) {
        return this.empresaRepository.findOne({
            where: { id },
            relations: [
                'propietario',
                'posts',
                'servicios',
                'resenas',
                'resenas.usuario',
            ],
        });
    }
    findByPropietario(propietarioId) {
        return this.empresaRepository.find({
            where: { propietario: { id: propietarioId } },
            order: { fechaRegistro: 'DESC' },
        });
    }
    async create(createEmpresaDto, propietarioId) {
        const propietario = await this.usuarioRepo.findOne({
            where: { id: propietarioId },
        });
        if (!propietario) {
            throw new Error('Usuario propietario no encontrado');
        }
        const nuevaEmpresa = this.empresaRepository.create({
            ...createEmpresaDto,
            propietario,
        });
        return this.empresaRepository.save(nuevaEmpresa);
    }
    async update(id, empresa) {
        await this.empresaRepository.update(id, empresa);
        return this.empresaRepository.findOneBy({ id });
    }
    async remove(id) {
        await this.empresaRepository.delete(id);
    }
};
exports.EmpresasService = EmpresasService;
exports.EmpresasService = EmpresasService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_2.InjectRepository)(empresa_entity_1.Empresa)),
    __param(1, (0, typeorm_2.InjectRepository)(usuario_entity_1.Usuario)),
    __metadata("design:paramtypes", [typeorm_1.Repository,
        typeorm_1.Repository])
], EmpresasService);
//# sourceMappingURL=empresas.service.js.map