export declare class CreateResenaDto {
    calificacion: number;
    comentario?: string;
    idEmpresa: number;
}
declare const UpdateResenaDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateResenaDto>>;
export declare class UpdateResenaDto extends UpdateResenaDto_base {
}
export {};
