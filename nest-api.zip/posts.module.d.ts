export declare class PostsModule {
}
