"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImageType = void 0;
var ImageType;
(function (ImageType) {
    ImageType["AVATAR"] = "avatar";
    ImageType["PORTADA"] = "portada";
    ImageType["POST"] = "post";
})(ImageType || (exports.ImageType = ImageType = {}));
//# sourceMappingURL=upload.interface.js.map