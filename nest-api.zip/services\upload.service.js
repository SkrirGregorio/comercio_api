"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const multer = __importStar(require("multer"));
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
const upload_interface_1 = require("../interfaces/upload.interface");
const uuid_1 = require("uuid");
let UploadService = class UploadService {
    configService;
    uploadDir = path.join(process.cwd(), 'public', 'uploads');
    baseUrl;
    constructor(configService) {
        this.configService = configService;
        this.baseUrl = this.configService.get('BASE_URL', 'http://localhost:3000');
        this.ensureUploadDirectories();
    }
    ensureUploadDirectories() {
        const directories = [
            path.join(this.uploadDir, 'avatars'),
            path.join(this.uploadDir, 'portadas'),
            path.join(this.uploadDir, 'posts'),
        ];
        directories.forEach((dir) => {
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
        });
    }
    getMulterConfig(options) {
        const { type, maxSize = 5 * 1024 * 1024, allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp'], } = options;
        return {
            storage: multer.diskStorage({
                destination: (req, file, cb) => {
                    const uploadPath = path.join(this.uploadDir, this.getUploadSubdirectory(type));
                    cb(null, uploadPath);
                },
                filename: (req, file, cb) => {
                    const fileExtension = path.extname(file.originalname);
                    const fileName = `${(0, uuid_1.v4)()}${fileExtension}`;
                    cb(null, fileName);
                },
            }),
            fileFilter: (req, file, cb) => {
                if (allowedMimeTypes.includes(file.mimetype)) {
                    cb(null, true);
                }
                else {
                    cb(null, false);
                }
            },
            limits: {
                fileSize: maxSize,
            },
        };
    }
    getUploadSubdirectory(type) {
        switch (type) {
            case upload_interface_1.ImageType.AVATAR:
                return 'avatars';
            case upload_interface_1.ImageType.PORTADA:
                return 'portadas';
            case upload_interface_1.ImageType.POST:
                return 'posts';
            default:
                return 'misc';
        }
    }
    generateFileUrl(filename, type) {
        const subdirectory = this.getUploadSubdirectory(type);
        return `${this.baseUrl}/uploads/${subdirectory}/${filename}`;
    }
    processUploadResult(file, type) {
        if (!file) {
            throw new common_1.BadRequestException('No se proporcionó ningún archivo');
        }
        return {
            filename: file.filename,
            originalName: file.originalname,
            size: file.size,
            mimetype: file.mimetype,
            url: this.generateFileUrl(file.filename, type),
        };
    }
    deleteFile(filename, type) {
        try {
            const subdirectory = this.getUploadSubdirectory(type);
            const filePath = path.join(this.uploadDir, subdirectory, filename);
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                return true;
            }
            return false;
        }
        catch (error) {
            console.error('Error deleting file:', error);
            return false;
        }
    }
    validateFileType(file, allowedTypes) {
        return allowedTypes.includes(file.mimetype);
    }
    async saveUploadedFile(file, type) {
        if (!file) {
            throw new common_1.BadRequestException('No se proporcionó ningún archivo');
        }
        const fileExtension = path.extname(file.originalname);
        const fileName = `${(0, uuid_1.v4)()}${fileExtension}`;
        const subdirectory = this.getUploadSubdirectory(type);
        const uploadPath = path.join(this.uploadDir, subdirectory);
        const filePath = path.join(uploadPath, fileName);
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        fs.writeFileSync(filePath, file.buffer);
        return {
            filename: fileName,
            originalName: file.originalname,
            size: file.size,
            mimetype: file.mimetype,
            url: this.generateFileUrl(fileName, type),
        };
    }
};
exports.UploadService = UploadService;
exports.UploadService = UploadService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], UploadService);
//# sourceMappingURL=upload.service.js.map