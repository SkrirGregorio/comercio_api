export declare class CreateEmpresaDto {
    nombre: string;
    descripcion?: string;
    direccion: string;
    telefono?: string;
    email?: string;
    latitud: number;
    longitud: number;
    horario?: string;
    urlAvatar?: string;
    webSite?: string;
    urlPortada?: string;
}
declare const UpdateEmpresaDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateEmpresaDto>>;
export declare class UpdateEmpresaDto extends UpdateEmpresaDto_base {
}
export {};
