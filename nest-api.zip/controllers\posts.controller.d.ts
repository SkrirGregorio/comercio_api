import { PostsService } from '../services/posts.service';
import { CreatePostDto, UpdatePostDto } from '../dtos/post.dto';
import { Request as ExpressRequest } from 'express';
export declare class PostsController {
    private readonly postsService;
    constructor(postsService: PostsService);
    create(createPostDto: CreatePostDto, req: ExpressRequest & {
        user: {
            userId: number;
        };
    }): Promise<import("../entities/post.entity").Post>;
    findAll(): Promise<import("../entities/post.entity").Post[]>;
    findByEmpresa(empresaId: number): Promise<import("../entities/post.entity").Post[]>;
    findOne(id: number): Promise<import("../entities/post.entity").Post>;
    update(id: number, updatePostDto: UpdatePostDto, req: ExpressRequest & {
        user: {
            userId: number;
        };
    }): Promise<import("../entities/post.entity").Post>;
    remove(id: number, req: ExpressRequest & {
        user: {
            userId: number;
        };
    }): Promise<void>;
}
