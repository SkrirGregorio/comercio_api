import { AuthService } from '../services/auth.service';
import { CreateUsuarioDto, UpdateUsuarioDto } from 'src/usuarios/dto/create-usuario.dto';
import type { Request } from 'express';
import { Usuario } from '../../usuarios/entities/usuario.entity';
export declare class AuthController {
    private authService;
    constructor(authService: AuthService);
    register(userDto: CreateUsuarioDto): Promise<Usuario>;
    login(req: Request & {
        user: any;
    }): {
        access_token: string;
    };
    updateProfile(updateProfileDto: UpdateUsuarioDto, user: Usuario): Promise<{
        id: number;
        nombre: string;
        email: string;
        role: import("../../usuarios/entities/usuario.entity").Role;
        photoUrl: string;
        isActive: boolean;
        google_id: string;
        createdAt: Date;
        updatedAt: Date;
        empresas: import("../../empresas/entities/empresa.entity").Empresa[];
        resenas: import("../../resenas/entities/resena.entity").Resena[];
    }>;
    getProfile(user: any): Promise<{
        id: number;
        nombre: string;
        email: string;
        role: import("../../usuarios/entities/usuario.entity").Role;
        photoUrl: string;
        isActive: boolean;
        google_id: string;
        createdAt: Date;
        updatedAt: Date;
        empresas: import("../../empresas/entities/empresa.entity").Empresa[];
        resenas: import("../../resenas/entities/resena.entity").Resena[];
    }>;
}
