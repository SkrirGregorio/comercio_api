import { Repository } from 'typeorm';
import { Servicio } from '../entities/servicio.entity';
import { CreateServicioDto, UpdateServicioDto } from '../dtos/servicio.dto';
export declare class ServiciosService {
    private readonly servicioRepo;
    constructor(servicioRepo: Repository<Servicio>);
    create(createServicioDto: CreateServicioDto): Promise<Servicio>;
    findAll(): Promise<Servicio[]>;
    findOne(id: number): Promise<Servicio>;
    update(id: number, updateServicioDto: UpdateServicioDto): Promise<Servicio>;
    remove(id: number): Promise<void>;
    searchByName(nombre: string): Promise<Servicio[]>;
}
