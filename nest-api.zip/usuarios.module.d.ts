export declare class UsuariosModule {
}
