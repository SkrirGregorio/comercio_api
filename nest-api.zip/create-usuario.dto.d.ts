import { Role } from '../entities/usuario.entity';
export declare class CreateUsuarioDto {
    nombre: string;
    email: string;
    password: string;
    photoUrl?: string;
    role: Role;
}
declare const UpdateUsuarioDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateUsuarioDto>>;
export declare class UpdateUsuarioDto extends UpdateUsuarioDto_base {
}
export {};
