import { Empresa } from '../../empresas/entities/empresa.entity';
export declare class Servicio {
    id: number;
    nombre: string;
    descripcion: string;
    empresas: Empresa[];
}
