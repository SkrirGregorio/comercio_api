"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const post_entity_1 = require("../entities/post.entity");
const empresa_entity_1 = require("../../empresas/entities/empresa.entity");
let PostsService = class PostsService {
    postRepo;
    empresaRepo;
    constructor(postRepo, empresaRepo) {
        this.postRepo = postRepo;
        this.empresaRepo = empresaRepo;
    }
    async create(createPostDto, userId) {
        const { empresaId, ...postData } = createPostDto;
        const empresa = await this.empresaRepo.findOne({
            where: { id: empresaId },
            relations: ['propietario'],
        });
        if (!empresa) {
            throw new common_1.NotFoundException(`Empresa con ID #${empresaId} no encontrada.`);
        }
        const nuevoPost = this.postRepo.create({
            ...postData,
            empresa,
        });
        return this.postRepo.save(nuevoPost);
    }
    findAll() {
        return this.postRepo.find({
            relations: ['empresa'],
        });
    }
    findByEmpresa(empresaId) {
        return this.postRepo.find({
            where: { empresa: { id: empresaId } },
            relations: ['empresa', 'empresa.propietario'],
            order: { createdAt: 'DESC' },
        });
    }
    async findOne(id) {
        const post = await this.postRepo.findOne({
            where: { id },
            relations: ['empresa', 'empresa.propietario'],
        });
        if (!post) {
            throw new common_1.NotFoundException(`Post con ID #${id} no encontrado.`);
        }
        return post;
    }
    async update(id, updatePostDto, userId) {
        const post = await this.findOne(id);
        if (post.empresa.propietario.id !== userId) {
            throw new common_1.UnauthorizedException('No tienes permiso para modificar este post.');
        }
        const { empresaId, ...updateData } = updatePostDto;
        this.postRepo.merge(post, updateData);
        return this.postRepo.save(post);
    }
    async remove(id, userId) {
        const post = await this.findOne(id);
        if (post.empresa.propietario.id !== userId) {
            throw new common_1.UnauthorizedException('No tienes permiso para eliminar este post.');
        }
        const result = await this.postRepo.delete(id);
        if (result.affected === 0) {
            throw new common_1.NotFoundException(`Post con ID #${id} no encontrado.`);
        }
    }
};
exports.PostsService = PostsService;
exports.PostsService = PostsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(post_entity_1.Post)),
    __param(1, (0, typeorm_1.InjectRepository)(empresa_entity_1.Empresa)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], PostsService);
//# sourceMappingURL=posts.service.js.map