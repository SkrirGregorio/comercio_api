"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiciosService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const servicio_entity_1 = require("../entities/servicio.entity");
let ServiciosService = class ServiciosService {
    servicioRepo;
    constructor(servicioRepo) {
        this.servicioRepo = servicioRepo;
    }
    async create(createServicioDto) {
        const servicioExistente = await this.servicioRepo.findOne({
            where: { nombre: createServicioDto.nombre },
        });
        if (servicioExistente) {
            throw new common_1.ConflictException(`Ya existe un servicio con el nombre "${createServicioDto.nombre}".`);
        }
        const nuevoServicio = this.servicioRepo.create(createServicioDto);
        return this.servicioRepo.save(nuevoServicio);
    }
    findAll() {
        return this.servicioRepo.find({
            order: { nombre: 'ASC' },
        });
    }
    async findOne(id) {
        const servicio = await this.servicioRepo.findOne({
            where: { id },
            relations: ['empresas'],
        });
        if (!servicio) {
            throw new common_1.NotFoundException(`Servicio con ID #${id} no encontrado.`);
        }
        return servicio;
    }
    async update(id, updateServicioDto) {
        const servicio = await this.servicioRepo.findOne({ where: { id } });
        if (!servicio) {
            throw new common_1.NotFoundException(`Servicio con ID #${id} no encontrado.`);
        }
        if (updateServicioDto.nombre && updateServicioDto.nombre !== servicio.nombre) {
            const servicioConMismoNombre = await this.servicioRepo.findOne({
                where: { nombre: updateServicioDto.nombre },
            });
            if (servicioConMismoNombre) {
                throw new common_1.ConflictException(`Ya existe un servicio con el nombre "${updateServicioDto.nombre}".`);
            }
        }
        this.servicioRepo.merge(servicio, updateServicioDto);
        return this.servicioRepo.save(servicio);
    }
    async remove(id) {
        const servicio = await this.servicioRepo.findOne({
            where: { id },
            relations: ['empresas'],
        });
        if (!servicio) {
            throw new common_1.NotFoundException(`Servicio con ID #${id} no encontrado.`);
        }
        if (servicio.empresas && servicio.empresas.length > 0) {
            throw new common_1.ConflictException(`No se puede eliminar el servicio "${servicio.nombre}" porque está siendo usado por ${servicio.empresas.length} empresa(s).`);
        }
        await this.servicioRepo.delete(id);
    }
    async searchByName(nombre) {
        return this.servicioRepo
            .createQueryBuilder('servicio')
            .where('servicio.nombre ILIKE :nombre', { nombre: `%${nombre}%` })
            .orderBy('servicio.nombre', 'ASC')
            .getMany();
    }
};
exports.ServiciosService = ServiciosService;
exports.ServiciosService = ServiciosService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(servicio_entity_1.Servicio)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], ServiciosService);
//# sourceMappingURL=servicios.service.js.map