import { Empresa } from '../../empresas/entities/empresa.entity';
import { Resena } from '../../resenas/entities/resena.entity';
export declare enum Role {
    ADMIN = "admin",
    CONSUMIDOR = "consumidor",
    PROPIETARIO = "propietario"
}
export declare class Usuario {
    id: number;
    nombre: string;
    email: string;
    password: string;
    role: Role;
    photoUrl: string;
    isActive: boolean;
    google_id: string;
    createdAt: Date;
    updatedAt: Date;
    empresas: Empresa[];
    resenas: Resena[];
}
