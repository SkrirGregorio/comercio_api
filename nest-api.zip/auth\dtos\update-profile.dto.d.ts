export declare class UpdateProfileDto {
    nombre?: string;
    email?: string;
    telefono?: string;
    photoUrl?: string;
}
