import { ServiciosService } from '../services/servicios.service';
import { CreateServicioDto, UpdateServicioDto } from '../dtos/servicio.dto';
export declare class ServiciosController {
    private readonly serviciosService;
    constructor(serviciosService: ServiciosService);
    create(createServicioDto: CreateServicioDto): Promise<import("../entities/servicio.entity").Servicio>;
    findAll(): Promise<import("../entities/servicio.entity").Servicio[]>;
    searchByName(nombre: string): Promise<import("../entities/servicio.entity").Servicio[]>;
    findOne(id: number): Promise<import("../entities/servicio.entity").Servicio>;
    update(id: number, updateServicioDto: UpdateServicioDto): Promise<import("../entities/servicio.entity").Servicio>;
    remove(id: number): Promise<void>;
}
