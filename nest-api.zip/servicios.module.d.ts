export declare class ServiciosModule {
}
