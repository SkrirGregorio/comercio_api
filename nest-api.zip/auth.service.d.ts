import { CreateUsuarioDto, UpdateUsuarioDto } from 'src/usuarios/dto/create-usuario.dto';
import { UsuarioService } from 'src/usuarios/services/usuario.service';
import { JwtService } from '@nestjs/jwt';
export declare class AuthService {
    private userService;
    private jwtService;
    constructor(userService: UsuarioService, jwtService: JwtService);
    register(userDto: CreateUsuarioDto): Promise<import("../../usuarios/entities/usuario.entity").Usuario>;
    validateUser(email: string, password: string): Promise<any>;
    login(user: any): {
        access_token: string;
    };
    updateProfile(userId: number, updateData: UpdateUsuarioDto): Promise<{
        id: number;
        nombre: string;
        email: string;
        role: import("../../usuarios/entities/usuario.entity").Role;
        photoUrl: string;
        isActive: boolean;
        google_id: string;
        createdAt: Date;
        updatedAt: Date;
        empresas: import("../../empresas/entities/empresa.entity").Empresa[];
        resenas: import("../../resenas/entities/resena.entity").Resena[];
    }>;
    getProfile(userId: number): Promise<{
        id: number;
        nombre: string;
        email: string;
        role: import("../../usuarios/entities/usuario.entity").Role;
        photoUrl: string;
        isActive: boolean;
        google_id: string;
        createdAt: Date;
        updatedAt: Date;
        empresas: import("../../empresas/entities/empresa.entity").Empresa[];
        resenas: import("../../resenas/entities/resena.entity").Resena[];
    }>;
}
